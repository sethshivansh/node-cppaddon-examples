#include <string>
#include <memory>
#include "absl/status/statusor.h"
#include "tink/aead/aead_config.h"
#include "tink/config/tink_config.h"
#include "tink/aead/aead_key_templates.h"
#include "tink/keyset_handle.h"
#include "tink/aead.h"

namespace tinkdemo {

absl::StatusOr<std::string> EncryptWithNewKey(const std::string& plaintext,
                                              const std::string& aad) {
  // Register all standard configs.
  auto reg_status = crypto::tink::TinkConfig::Register();
  if (!reg_status.ok()) {
    return reg_status;
  }

  // Create a new AEAD keyset (AES256_GCM).
  auto keyset_result =
      crypto::tink::KeysetHandle::GenerateNew(
          crypto::tink::AeadKeyTemplates::Aes256Gcm());
  if (!keyset_result.ok()) {
    return keyset_result.status();
  }

  std::unique_ptr<crypto::tink::Aead> aead =
      keyset_result.value()->GetPrimitive<crypto::tink::Aead>().value();

  auto ct_result = aead->Encrypt(plaintext, aad);
  if (!ct_result.ok()) {
    return ct_result.status();
  }

  return ct_result.value();
}

}  // namespace tinkdemo