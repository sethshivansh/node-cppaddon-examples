const tinkAddon = require('./build/Release/addon');
console.log(`2 + 3 = ${tinkAddon.add(2, 3)}`);

tinkAddon.encryptData('Hello, World!').then((encrypted) => {
  console.log(`Encrypted: ${encrypted}`);
});