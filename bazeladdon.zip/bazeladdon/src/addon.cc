// // #include "node-addon-api/napi.h"
// // #include "tink/aead/aead_config.h"
// // #include "tink/aead/aead_key_templates.h"
// // #include "tink/keyset_handle.h"
// // #include "tink/registry.h"
// // #include "tink/aead.h"
// // #include <iostream>
// // #include <string>

// // std::unique_ptr<crypto::tink::Aead> global_aead;

// // Napi::String Encrypt(const Napi::CallbackInfo& info) {
// //   Napi::Env env = info.Env();
// //   if (info.Length() < 1 || !info[0].IsString()) {
// //     Napi::TypeError::New(env, "String expected for plaintext").ThrowAsJavaScriptException();
// //     return Napi::String::New(env, "");
// //   }
// //   std::string plaintext = info[0].As<Napi::String>().Utf8Value();
// //   std::string aad = "some associated data"; // Optional AAD

// //   auto encrypt_result = global_aead->Encrypt(plaintext, aad);
// //   if (!encrypt_result.ok()) {
// //     Napi::Error::New(env, "Encryption failed").ThrowAsJavaScriptException();
// //     return Napi::String::New(env, "");
// //   }
// //   std::string ciphertext = encrypt_result.value();
// //   // Note: This returns raw bytes as a string, you might want to use Buffer or base64 encoding for JS
// //   return Napi::String::New(env, ciphertext);
// // }

// // Napi::Value Add(const Napi::CallbackInfo& info) {
// //   Napi::Env env = info.Env();

// //   if (info.Length() < 2) {
// //     Napi::TypeError::New(env, "Wrong number of arguments").ThrowAsJavaScriptException();
// //     return env.Undefined();
// //   }

// //   if (!info[0].IsNumber() || !info[1].IsNumber()) {
// //     Napi::TypeError::New(env, "Wrong arguments").ThrowAsJavaScriptException();
// //     return env.Undefined();
// //   }

// //   double arg1 = info[0].As<Napi::Number>().DoubleValue();
// //   double arg2 = info[1].As<Napi::Number>().DoubleValue();
// //   Napi::Number num = Napi::Number::New(env, arg1 + arg2);

// //   return num;
// // }


// // Napi::Object Init(Napi::Env env, Napi::Object exports) {
// //   // 1. Initialize Tink
// //   crypto::tink::TinkConfig::Register();
// //   crypto::tink::AeadConfig::Register();

// //   // 2. Generate a new keyset handle
// //   auto keyset_handle_result = crypto::tink::KeysetHandle::GenerateNew(
// //       crypto::tink::AeadKeyTemplates::Aes128Gcm());
// //   if (!keyset_handle_result.ok()) {
// //       std::cerr << "Failed to generate keyset: " << keyset_handle_result.status().message() << std::endl;
// //       return exports;
// //   }
// //   std::unique_ptr<crypto::tink::KeysetHandle> keyset_handle = std::move(keyset_handle_result.value());

// //   // 3. Get the primitive (AEAD object)
// //   auto aead_result = keyset_handle->GetPrimitive<const crypto::tink::Aead>();
// //   if (!aead_result.ok()) {
// //       std::cerr << "Failed to get AEAD primitive: " << aead_result.status().message() << std::endl;
// //       return exports;
// //   }
// //   global_aead = std::move(aead_result.value());

// //   // Expose the Encrypt function to Node.js
// //   exports.Set(Napi::String::New(env, "encrypt"), Napi::Function::New(env, Encrypt));
// //   exports.Set(Napi::String::New(env, "add"), Napi::Function::New(env, Add));

// //   return exports;
// // }


// #include <napi.h>
// #include <string>
// #include <iostream>
// #include "tink/aead/aead_config.h"
// #include "tink/keyset_handle.h"
// #include "tink/aead/aead_key_templates.h"
// #include "tink/aead.h"

// using namespace crypto::tink;
// using namespace Napi;

// // Function to handle encryption
// Value EncryptData(const CallbackInfo& info) {
//     Env env = info.Env();

//     // 1. Validate inputs (Plaintext and Associated Data)
//     if (info.Length() < 2 || !info[0].IsString() || !info[1].IsString()) {
//         TypeError::New(env, "String arguments expected").ThrowAsJavaScriptException();
//         return env.Null();
//     }

//     std::string plaintext = info[0].As<String>().Utf8Value();
//     std::string associated_data = info[1].As<String>().Utf8Value();

//     // 2. Initialize Tink Configuration
//     auto status = AeadConfig::Register();
//     if (!status.ok()) {
//         Error::New(env, "Tink Registration Failed").ThrowAsJavaScriptException();
//         return env.Null();
//     }

//     // 3. Generate or load a KeysetHandle (Simplified for this example)
//     auto handle_result = KeysetHandle::GenerateNew(AeadKeyTemplates::Aes256Gcm());
//     if (!handle_result.ok()) {
//         Error::New(env, "Key generation failed").ThrowAsJavaScriptException();
//         return env.Null();
//     }
//     auto keyset_handle = std::move(handle_result.value());

//     // 4. Get the AEAD primitive
//     auto aead_result = keyset_handle->GetPrimitive<Aead>(Config::GlobalRegistry());
//     if (!aead_result.ok()) {
//         Error::New(env, "Primitive retrieval failed").ThrowAsJavaScriptException();
//         return env.Null();
//     }
//     auto aead = std::move(aead_result.value());

//     // 5. Encrypt
//     auto encrypt_result = aead->Encrypt(plaintext, associated_data);
//     if (!encrypt_result.ok()) {
//         Error::New(env, "Encryption failed").ThrowAsJavaScriptException();
//         return env.Null();
//     }

//     // 6. Return as Node.js Buffer
//     std::string ciphertext = encrypt_result.value();
//     return Buffer<char>::Copy(env, ciphertext.c_str(), ciphertext.length());
// }

// // Module initialization
// Object Init(Env env, Object exports) {
//     exports.Set(String::New(env, "encrypt"), Function::New(env, EncryptData));
//     return exports;
// }


// NODE_API_MODULE(tinkaddon, Init)