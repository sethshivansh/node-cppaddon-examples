// #include <napi.h>
// #include "tink/aead.h"
// #include "tink/aead/aead_config.h"
// #include "tink/aead/aead_key_templates.h"
// #include "tink/aead/kms_envelope_aead.h"
// #include "tink/integration/gcpkms/gcp_kms_client.h"

#include <napi.h>
#include <tink/aead.h>
#include <tink/config/tink_config.h>
#include <tink/keyset_handle.h>
#include <tink/aead/aead_key_templates.h>

#include "tink/json_keyset_reader.h"
#include <fstream>

#include "tink/aead/kms_envelope_aead.h"
#include "tink/integration/gcpkms/gcp_kms_client.h"

using namespace crypto::tink;
using namespace crypto::tink::integration::gcpkms;
using namespace Napi;

static std::unique_ptr<Aead> global_kms_aead;

// Initialization: Call once with your KMS URI and Service Account JSON path
bool InitKms(std::string kms_uri, std::string creds_path) {
    auto status = AeadConfig::Register();
    if (!status.ok()) return false;

    // 1. Create GCP KMS Client
    auto client_result = GcpKmsClient::New(kms_uri, creds_path);
    if (!client_result.ok()) return false;

    // 2. Get remote AEAD (The KEK)
    auto remote_aead = (*client_result)->GetAead(kms_uri);
    if (!remote_aead.ok()) return false;

    // 3. Create Envelope AEAD (DEK is AES-256 GCM)
    auto env_result = KmsEnvelopeAead::New(
        AeadKeyTemplates::Aes256Gcm(), std::move(remote_aead.value()));
    
    if (!env_result.ok()) return false;

    global_kms_aead = std::move(env_result.value());
    return true;
}

Value Encrypt(const CallbackInfo& info) {
    Env env = info.Env();
    if (!global_kms_aead) {
        Error::New(env, "KMS not initialized").ThrowAsJavaScriptException();
        return env.Null();
    }

    std::string plaintext = info[0].As<String>();
    std::string aad = info[1].As<String>();

    auto result = global_kms_aead->Encrypt(plaintext, aad);
    if (!result.ok()) {
        Error::New(env, "KMS Encrypt failed").ThrowAsJavaScriptException();
        return env.Null();
    }

    return Buffer<char>::Copy(env, result.value().data(), result.value().size());
}

Value Decrypt(const CallbackInfo& info) {
    Env env = info.Env();
    Buffer<char> cipher_buf = info[0].As<Buffer<char>>();
    std::string ciphertext(cipher_buf.Data(), cipher_buf.Length());
    std::string aad = info[1].As<String>();

    auto result = global_kms_aead->Decrypt(ciphertext, aad);
    if (!result.ok()) {
        Error::New(env, "KMS Decrypt failed").ThrowAsJavaScriptException();
        return env.Null();
    }

    return String::New(env, result.value());
}

Object Init(Env env, Object exports) {
    // Replace with your actual URI and local credentials path
    std::string uri = "gcp-kms://projects/[ID]/locations/global/keyRings/[RING]/cryptoKeys/[KEY]";
    if (!InitKms(uri, "./credentials.json")) {
        Error::New(env, "Failed to connect to Google KMS").ThrowAsJavaScriptException();
    }

    exports.Set("encrypt", Function::New(env, Encrypt));
    exports.Set("decrypt", Function::New(env, Decrypt));
    return exports;
}

NODE_API_MODULE(tinkaddon, Init)
