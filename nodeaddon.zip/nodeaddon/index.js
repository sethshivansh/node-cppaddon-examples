// index.js
const addon = require('./build/Release/addon.node');

console.log('2 + 3 =', addon.add(2, 3)); // Output: 2 + 3 = 5
console.log('2 * 3 =', addon.multiply(2, 3)); // Output: 2 * 3 = 6
